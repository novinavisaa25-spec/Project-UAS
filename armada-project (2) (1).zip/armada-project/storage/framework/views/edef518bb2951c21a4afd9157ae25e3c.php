

<?php $__env->startSection('title', 'Profil Tim'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h1 class="text-center mb-4">Profil Tim Kami</h1>
    <p class="text-center text-muted">Tim profesional dan berpengalaman siap melayani Anda</p>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-3 col-sm-6 mb-4">
        <div class="card h-100 shadow-sm text-center">
            <div class="card-body">
                    <img src="<?php echo e($driver->foto_url); ?>" 
                         alt="<?php echo e($driver->nama); ?>" 
                         class="rounded-circle mb-3" 
                         width="120" 
                         height="120"
                         style="object-fit: cover; border: 4px solid #007bff;">
                
                <h5 class="card-title mb-1"><?php echo e($driver->nama); ?></h5>
                <p class="text-muted mb-2">
                    <small>
                        <i class="fas fa-id-badge text-primary"></i>
                        <?php echo e($driver->jabatan); ?>

                    </small>
                </p>
                
                <?php if($driver->bio): ?>
                <p class="card-text small"><?php echo e(Str::limit($driver->bio, 80)); ?></p>
                <?php endif; ?>
                
                <hr>
                <?php
                    $phone = preg_replace('/\D+/', '', $driver->telepon ?? '');
                    $whText = urlencode('Halo ' . $driver->nama . ', saya ingin informasi lebih lanjut.');
                    $whLink = $phone ? ('https://wa.me/' . $phone . '?text=' . $whText) : '#';
                ?>
                <div class="d-flex justify-content-center gap-2">
                    <?php if($phone): ?>
                        <a href="<?php echo e($whLink); ?>" target="_blank" class="btn btn-success btn-sm" title="Chat WhatsApp <?php echo e($driver->nama); ?>">
                            <i class="fab fa-whatsapp"></i> WA
                        </a>
                    <?php else: ?>
                        <span class="text-muted">Kontak tidak tersedia</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle"></i>
            Belum ada data tim tersedia.
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/public/driver/index.blade.php ENDPATH**/ ?>