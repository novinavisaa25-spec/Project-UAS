

<?php $__env->startSection('title', 'Data Armada'); ?>

<?php $__env->startSection('page-title', 'Manajemen Armada'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Armada</h3>
        <div class="card-tools">
            <a href="<?php echo e(route('admin.armada.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Armada
            </a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Nomor Polisi</th>
                    <th>Jenis</th>
                    <th>Merk</th>
                    <th>Kapasitas</th>
                    <th>Tahun</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $armadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $armada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td>
                        <img src="<?php echo e($armada->foto_url); ?>" alt="Foto" width="80">
                    </td>
                    <td><?php echo e($armada->nomor_polisi); ?></td>
                    <td><?php echo e($armada->jenis_kendaraan); ?></td>
                    <td><?php echo e($armada->merk); ?></td>
                    <td><?php echo e($armada->kapasitas_muatan); ?></td>
                    <td><?php echo e($armada->tahun_pembuatan); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $armada->status))); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.armada.show', $armada)); ?>" class="btn btn-info btn-sm">
                            <i class="fas fa-eye"></i> View
                        </a>
                        <a href="<?php echo e(route('admin.armada.edit', $armada)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <?php if($armada->trackings_count || $armada->services_count): ?>
                            <button class="btn btn-danger btn-sm" disabled title="Tidak dapat dihapus: ada data terkait (pengiriman/service)">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        <?php else: ?>
                            <form action="<?php echo e(route('admin.armada.destroy', $armada)); ?>" method="POST" style="display:inline;" 
                                  onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">Belum ada data armada</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/armada/index.blade.php ENDPATH**/ ?>