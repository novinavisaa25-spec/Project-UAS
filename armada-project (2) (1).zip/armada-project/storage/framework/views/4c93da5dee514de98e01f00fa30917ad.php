

<?php $__env->startSection('title', 'Lokasi Gudang'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h1 class="text-center mb-4">Lokasi Gudang Kami</h1>
    <p class="text-center text-muted">Temukan gudang terdekat dari lokasi Anda</p>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $gudangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gudang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
            <div class="card-body">
                <h5 class="card-title">
                    <i class="fas fa-warehouse text-primary"></i>
                    <?php echo e($gudang->nama); ?>

                </h5>
                <hr>
                <div class="mb-3">
                    <p><strong><i class="fas fa-map-marker-alt text-danger"></i> Alamat:</strong></p>
                    <p class="ms-4"><?php echo e($gudang->alamat); ?></p>
                </div>
                <div class="mb-3">
                    <p><strong><i class="fas fa-box text-success"></i> Kapasitas:</strong></p>
                    <p class="ms-4"><?php echo e(number_format($gudang->kapasitas)); ?> unit</p>
                </div>
                
                <!-- Google Maps Embed (centered on alamat) -->
                <div class="ratio ratio-16x9">
                    <iframe
                        src="https://www.google.com/maps?q=<?php echo e(urlencode($gudang->alamat)); ?>&output=embed"
                        style="border:0;"
                        allowfullscreen=""
                        loading="lazy">
                    </iframe>
                </div> 
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle"></i>
            Belum ada data gudang tersedia.
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/public/gudang/index.blade.php ENDPATH**/ ?>