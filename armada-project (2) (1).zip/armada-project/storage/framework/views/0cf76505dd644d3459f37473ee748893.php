

<?php $__env->startSection('title', 'Tracking Pengiriman'); ?>
<?php $__env->startSection('page-title', 'Manajemen Tracking'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Tracking Pengiriman</h3>
        <div class="card-tools">
            <a href="<?php echo e(route('admin.tracking.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Tracking
            </a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Resi</th>
                    <th>Armada</th>
                    <th>Driver</th>
                    <th>Rute</th>
                    <th>Status</th>
                    <th>Tgl Kirim</th>
                    <th>Tgl Sampai</th>
                    <th>Lokasi Terakhir</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tracking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><strong><?php echo e($tracking->no_resi); ?></strong></td>
                    <td><?php echo e($tracking->armada->nomor_polisi ?? '-'); ?></td>
                    <td><?php echo e($tracking->driver->nama ?? '-'); ?></td>
                    <td><?php echo e($tracking->rute->nama_rute ?? '-'); ?></td>
                    <td>
                        <?php $status = $tracking->status_pengiriman; ?>
                        <?php if($status == 'sampai'): ?>
                            <span class="badge badge-success"><?php echo e(ucfirst(str_replace('_', ' ', $status))); ?></span>
                        <?php elseif($status == 'dalam_perjalanan'): ?>
                            <span class="badge badge-warning"><?php echo e(ucfirst(str_replace('_', ' ', $status))); ?></span>
                        <?php else: ?>
                            <span class="badge badge-info"><?php echo e(ucfirst(str_replace('_', ' ', $status))); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(optional($tracking->tanggal_kirim)->format('d/m/Y') ?? '-'); ?></td>
                    <td><?php echo e(optional($tracking->tanggal_sampai)->format('d/m/Y') ?? '-'); ?></td>
                    <td><?php echo e($tracking->lokasi_terakhir ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.tracking.show', $tracking)); ?>" class="btn btn-info btn-sm">
                            <i class="fas fa-eye"></i> View
                        </a>
                        <a href="<?php echo e(route('admin.tracking.edit', $tracking)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <form action="<?php echo e(route('admin.tracking.destroy', $tracking)); ?>" method="POST" style="display:inline;" 
                              onsubmit="return confirm('Yakin ingin menghapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="10" class="text-center">Belum ada data tracking</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/tracking/index.blade.php ENDPATH**/ ?>