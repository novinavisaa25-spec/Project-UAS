

<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('css'); ?>
<style>
    /* Minor tweaks for AdminLTE components */
    .chart-card { min-height: 260px; }
    .small-box .icon { top: 10px; }
    .users-table td, .users-table th { vertical-align: middle; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Small boxes (Stat box) -->
    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo e(\App\Models\Armada::count()); ?></h3>
                    <p>Armada</p>
                </div>
                <div class="icon">
                    <i class="fas fa-bus"></i>
                </div>
                <a href="<?php echo e(route('admin.armada.index')); ?>" class="small-box-footer">Lihat <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
                <div class="inner">
                    <h3><?php echo e(\App\Models\Rute::count()); ?></h3>
                    <p>Rute</p>
                </div>
                <div class="icon"><i class="fas fa-route"></i></div>
                <a href="<?php echo e(route('admin.rute.index')); ?>" class="small-box-footer">Lihat <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
                <div class="inner">
                    <h3><?php echo e(\App\Models\Driver::count()); ?></h3>
                    <p>Driver</p>
                </div>
                <div class="icon"><i class="fas fa-users"></i></div>
                <a href="<?php echo e(route('admin.driver.index')); ?>" class="small-box-footer">Lihat <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>

        <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
                <div class="inner">
                    <h3><?php echo e(\App\Models\Gudang::count()); ?></h3>
                    <p>Gudang</p>
                </div>
                <div class="icon"><i class="fas fa-warehouse"></i></div>
                <a href="<?php echo e(route('admin.gudang.index')); ?>" class="small-box-footer">Lihat <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>

    <!-- Main row -->
    <div class="row">
        <section class="col-lg-7 connectedSortable">
            <!-- Ringkasan Pengiriman removed -->

            <!-- Latest orders / recent activities -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Aktivitas Terbaru</h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <ul class="products-list product-list-in-card pl-2 pr-2">
                        <?php $__currentLoopData = \App\Models\Tracking::latest()->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="item">
                            <div class="product-img">
                                <i class="fas fa-shipping-fast fa-2x text-primary"></i>
                            </div>
                            <div class="product-info">
                                <a href="<?php echo e(route('admin.tracking.show', $track)); ?>" class="product-title">Resi: <?php echo e($track->no_resi ?? '-'); ?>

                                    <span class="float-right text-muted"><?php echo e($track->status_pengiriman ?? 'Update'); ?></span></a>
                                <span class="product-description"><?php echo e(Str::limit($track->catatan ?? '', 80)); ?></span>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="card-footer text-center">
                    <a href="<?php echo e(route('admin.tracking.index')); ?>">Lihat Semua Pengiriman</a>
                </div>
            </div>
        </section>

        <section class="col-lg-5 connectedSortable">
            <!-- Info boxes -->
            <div class="info-box mb-3 bg-info">
                <span class="info-box-icon"><i class="fas fa-bus"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Total Armada</span>
                    <span class="info-box-number"><?php echo e(\App\Models\Armada::count()); ?></span>
                </div>
            </div>

            <div class="info-box mb-3 bg-success">
                <span class="info-box-icon"><i class="fas fa-route"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Total Rute</span>
                    <span class="info-box-number"><?php echo e(\App\Models\Rute::count()); ?></span>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Pengguna Terbaru</h3>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-hover users-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = \App\Models\User::latest()->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($u->name); ?></td>
                                <td><?php echo e($u->email); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer text-center">
                    <a href="<?php echo e(route('admin.user.index')); ?>">Lihat Semua Pengguna</a>
                </div>
            </div>

        </section>
    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>