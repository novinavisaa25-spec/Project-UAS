

<?php $__env->startSection('title', 'Data Driver'); ?>
<?php $__env->startSection('page-title', 'Manajemen Driver & Kru'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Driver & Kru</h3>
        <div class="card-tools">
            <a href="<?php echo e(route('admin.driver.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Driver
            </a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Nama</th>
                    <th>No. SIM</th>
                    <th>Telepon</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td>
                            <img src="<?php echo e($driver->foto_url); ?>" alt="Foto" width="60" class="rounded-circle">
                    </td>
                    <td><?php echo e($driver->nama); ?></td>
                    <td><?php echo e($driver->no_sim); ?></td>
                    <td><?php echo e($driver->telepon); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $driver->status_aktif))); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.driver.show', $driver)); ?>" class="btn btn-info btn-sm">
                            <i class="fas fa-eye"></i> View
                        </a>
                        <a href="<?php echo e(route('admin.driver.edit', $driver)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <form action="<?php echo e(route('admin.driver.destroy', $driver)); ?>" method="POST" style="display:inline;" 
                              onsubmit="return confirm('Yakin ingin menghapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">Belum ada data driver</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/driver/index.blade.php ENDPATH**/ ?>