

<?php $__env->startSection('title', 'Notifikasi'); ?>

<?php $__env->startSection('page-title', 'Notifikasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3 class="card-title">Semua Notifikasi</h3>
            <form action="<?php echo e(route('admin.notifications.markAllRead')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-secondary">Tandai Semua Dibaca</button>
            </form>
        </div>
        <div class="card-body">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-3 p-2 border rounded <?php echo e(is_null($note->read_at) ? 'bg-light' : ''); ?>">
                    <div class="d-flex justify-content-between">
                        <div>
                            <strong><?php echo e($note->data['title'] ?? 'Notifikasi'); ?></strong>
                            <div class="text-muted"><?php echo e($note->data['message'] ?? ''); ?></div>
                        </div>
                        <div class="text-right text-muted">
                            <small><?php echo e($note->created_at->diffForHumans()); ?></small>
                            <?php if(is_null($note->read_at)): ?>
                                <div><span class="badge badge-primary">Baru</span></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="mt-2">
                        <a href="<?php echo e(route('admin.notifications.show', $note->id)); ?>" class="btn btn-sm btn-outline-primary">Lihat</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mt-3">
                <?php echo e($notifications->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>