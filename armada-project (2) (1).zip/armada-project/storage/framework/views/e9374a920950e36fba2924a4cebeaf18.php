

<?php $__env->startSection('title', 'Cek Area Layanan'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h1 class="text-center mb-4">Cek Area Layanan Kami</h1>
    <p class="text-center text-muted">Jangkauan rute pengiriman kami</p>
</div>

<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $rutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
            <div class="card-body">
                <h5 class="card-title">
                    <i class="fas fa-map-marker-alt text-success"></i>
                    <?php echo e($rute->asal); ?> 
                    <i class="fas fa-arrow-right text-primary mx-2"></i> 
                    <?php echo e($rute->tujuan); ?>

                </h5>
                <hr>
                <div class="mb-2">
                    <i class="fas fa-road text-info"></i>
                    <strong>Jarak:</strong> <?php echo e($rute->jarak_km); ?> Km
                </div>
                <?php if($rute->deskripsi): ?>
                <div>
                    <i class="fas fa-info-circle text-secondary"></i>
                    <strong>Info:</strong> <?php echo e($rute->deskripsi); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle"></i>
            Belum ada data rute tersedia.
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/public/rute/index.blade.php ENDPATH**/ ?>