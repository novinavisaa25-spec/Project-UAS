

<?php $__env->startSection('title', 'Detail Tracking'); ?>
<?php $__env->startSection('page-title', 'Detail Tracking'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Detail Tracking</h3>
    </div>
    <div class="card-body">
        <dl class="row">
            <dt class="col-sm-3">No. Resi</dt>
            <dd class="col-sm-9"><?php echo e($tracking->no_resi); ?></dd>

            <dt class="col-sm-3">Armada</dt>
            <dd class="col-sm-9"><?php echo e($tracking->armada->nomor_polisi ?? '-'); ?> - <?php echo e($tracking->armada->jenis_kendaraan ?? ''); ?></dd>

            <dt class="col-sm-3">Driver</dt>
            <dd class="col-sm-9"><?php echo e($tracking->driver->nama ?? '-'); ?> (<?php echo e($tracking->driver->no_sim ?? ''); ?>)</dd>

            <dt class="col-sm-3">Rute</dt>
            <dd class="col-sm-9"><?php echo e($tracking->rute->nama_rute ?? '-'); ?> (<?php echo e($tracking->rute->asal ?? ''); ?> - <?php echo e($tracking->rute->tujuan ?? ''); ?>)</dd>

            <dt class="col-sm-3">Status Pengiriman</dt>
            <dd class="col-sm-9"><?php echo e(ucfirst(str_replace('_', ' ', $tracking->status_pengiriman))); ?></dd>

            <dt class="col-sm-3">Tanggal Kirim</dt>
            <dd class="col-sm-9"><?php echo e(optional($tracking->tanggal_kirim)->format('d/m/Y') ?? '-'); ?></dd>

            <dt class="col-sm-3">Tanggal Sampai</dt>
            <dd class="col-sm-9"><?php echo e(optional($tracking->tanggal_sampai)->format('d/m/Y') ?? '-'); ?></dd>

            <dt class="col-sm-3">Lokasi Terakhir</dt>
            <dd class="col-sm-9"><?php echo e($tracking->lokasi_terakhir ?? '-'); ?></dd>

            <dt class="col-sm-3">Catatan</dt>
            <dd class="col-sm-9"><?php echo e($tracking->catatan ?? '-'); ?></dd>

            <dt class="col-sm-3">Dibuat</dt>
            <dd class="col-sm-9"><?php echo e($tracking->created_at->format('d/m/Y H:i')); ?></dd>

            <dt class="col-sm-3">Terakhir Diupdate</dt>
            <dd class="col-sm-9"><?php echo e($tracking->updated_at->format('d/m/Y H:i')); ?></dd>
        </dl>
    </div>
    <div class="card-footer">
        <a href="<?php echo e(route('admin.tracking.index')); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Kembali</a>
        <a href="<?php echo e(route('admin.tracking.edit', $tracking)); ?>" class="btn btn-warning"><i class="fas fa-edit"></i> Edit</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/tracking/show.blade.php ENDPATH**/ ?>