

<?php $__env->startSection('title', 'Cek Resi'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow">
            <div class="card-body">
                <h1 class="text-center mb-4">
                    <i class="fas fa-search-location text-primary"></i> Cek Resi Pengiriman
                </h1>
                <p class="text-center text-muted mb-4">Masukkan nomor resi untuk melacak paket Anda</p>
                
                <form method="GET" action="<?php echo e(url('/cek-resi')); ?>">
                    <div class="input-group mb-3">
                        <input type="text" 
                               name="resi" 
                               class="form-control form-control-lg" 
                               placeholder="Masukkan No. Resi" 
                               value="<?php echo e(request('resi')); ?>"
                               required>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-search"></i> Cek Resi
                        </button>
                    </div>
                </form>

                <?php if(request('resi')): ?>
                    <?php if($tracking): ?>
                    <div class="alert alert-success mt-4">
                        <h4 class="alert-heading">
                            <i class="fas fa-check-circle"></i> Paket Ditemukan!
                        </h4>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>No. Resi:</strong><br><?php echo e($tracking->no_resi); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Status:</strong><br>
                                    <?php $st = $tracking->status_pengiriman; ?>
                                    <?php if($st == 'sampai'): ?>
                                        <span class="badge bg-success p-2"><?php echo e(ucfirst(str_replace('_', ' ', $st))); ?></span>
                                    <?php elseif($st == 'dalam_perjalanan'): ?>
                                        <span class="badge bg-warning p-2"><?php echo e(ucfirst(str_replace('_', ' ', $st))); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-info p-2"><?php echo e(ucfirst(str_replace('_', ' ', $st))); ?></span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                        <?php if($tracking->lokasi_terakhir): ?>
                        <p class="mb-0">
                            <strong><i class="fas fa-map-marker-alt text-danger"></i> Lokasi Terakhir:</strong><br>
                            <?php echo e($tracking->lokasi_terakhir); ?>

                        </p>
                        <?php endif; ?>
                        <hr>
                        <p class="mb-0 text-muted">
                            <small>Terakhir diupdate: <?php echo e($tracking->updated_at->format('d F Y, H:i')); ?> WIB</small>
                        </p>
                    </div>
                    <?php else: ?>
                    <div class="alert alert-danger mt-4">
                        <h5 class="alert-heading">
                            <i class="fas fa-exclamation-triangle"></i> Resi Tidak Ditemukan
                        </h5>
                        <p class="mb-0">Nomor resi <strong><?php echo e(request('resi')); ?></strong> tidak ditemukan dalam sistem kami. Pastikan nomor resi yang Anda masukkan benar.</p>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>

        <!-- Info Tambahan -->
        <div class="card mt-4">
            <div class="card-body">
                <h5><i class="fas fa-info-circle text-info"></i> Informasi Status</h5>
                <ul class="mb-0">
                    <li><strong>Dikirim:</strong> Paket telah dikirim dari gudang</li>
                    <li><strong>Dalam Perjalanan:</strong> Paket sedang dalam perjalanan menuju tujuan</li>
                    <li><strong>Sampai:</strong> Paket telah sampai di tujuan</li>
                </ul>
            </div>
        </div>

        <!-- Daftar Resi Aktif -->
        <div class="card mt-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="fas fa-list"></i> Daftar Resi Pengiriman Aktif
                </h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped table-hover">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 15%;">No. Resi</th>
                            <th style="width: 12%;">Status</th>
                            <th style="width: 20%;">Lokasi</th>
                            <th style="width: 12%;">Tgl Kirim</th>
                            <th style="width: 15%;">Driver</th>
                            <th style="width: 15%;" class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $allTrackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <strong class="text-primary"><?php echo e($item->no_resi); ?></strong>
                            </td>
                            <td>
                                <?php $st = $item->status_pengiriman; ?>
                                <?php if($st == 'sampai'): ?>
                                    <span class="badge bg-success">Sampai</span>
                                <?php elseif($st == 'dalam_perjalanan'): ?>
                                    <span class="badge bg-warning text-dark">Dalam Perjalanan</span>
                                <?php else: ?>
                                    <span class="badge bg-info">Dikirim</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->lokasi_terakhir ?? '-'); ?></td>
                            <td><?php echo e(optional($item->tanggal_kirim)->format('d/m/Y') ?? '-'); ?></td>
                            <td><?php echo e($item->driver->nama ?? '-'); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(url('/cek-resi?resi=' . $item->no_resi)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i> Lihat
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-3 text-muted">
                                <i class="fas fa-inbox"></i> Tidak ada resi pengiriman
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/public/tracking/index.blade.php ENDPATH**/ ?>