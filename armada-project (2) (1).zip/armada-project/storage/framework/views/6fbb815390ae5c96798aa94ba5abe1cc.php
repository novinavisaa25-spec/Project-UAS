

<?php $__env->startSection('title', 'Manajemen Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3 class="card-title">Manajemen User</h3>
        <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-primary">+ Tambah Akun</a>
    </div>

    <div class="card-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>



        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width:60px;">No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th style="width:200px;">Role</th>
                    <th style="width:160px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration + ($users->currentPage()-1)*$users->perPage()); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e(implode(', ', $user->getRoleNames()->toArray()) ?: '-'); ?></td>
                    <td>
                        <?php
                            $firstSuperAdmin = \App\Models\User::whereHas('roles', function($q){ $q->where('name','Super Admin'); })->orderBy('id')->first();
                            $firstId = $firstSuperAdmin ? $firstSuperAdmin->id : null;
                            $me = auth()->user();
                            $isSuperTarget = $user->hasRole('Super Admin');
                            $canManage = true;

                            if ($isSuperTarget) {
                                if ($me->id !== $firstId) {
                                    // only first super admin can manage superadmins
                                    $canManage = false;
                                }
                            }
                        ?>

                        <?php if($canManage): ?>
                            <a href="<?php echo e(route('admin.user.edit', $user)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <?php if(! $user->hasRole('Super Admin') || (auth()->user()->id === $firstId)): ?>
                                <form action="<?php echo e(route('admin.user.destroy', $user)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus pengguna ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">Delete</button>
                                </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <button class="btn btn-sm btn-secondary" disabled>--</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="d-flex justify-content-end">
            <?php echo e($users->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/user/index.blade.php ENDPATH**/ ?>