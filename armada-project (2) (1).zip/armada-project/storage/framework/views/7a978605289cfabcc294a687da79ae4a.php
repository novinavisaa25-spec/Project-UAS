

<?php $__env->startSection('title', 'Notifikasi'); ?>

<?php $__env->startSection('page-title', 'Notifikasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h4><?php echo e($notification->data['title'] ?? 'Notifikasi'); ?></h4>
            <p><?php echo e($notification->data['message'] ?? ''); ?></p>
            <p class="text-muted">Diterima: <?php echo e($notification->created_at->toDayDateTimeString()); ?></p>
            <a href="<?php echo e(route('admin.notifications.index')); ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/notifications/show.blade.php ENDPATH**/ ?>