

<?php $__env->startSection('title', 'Jadwal Service'); ?>
<?php $__env->startSection('page-title', 'Jadwal Service Kendaraan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Jadwal Service</h3>
        <div class="card-tools">
            <a href="<?php echo e(route('admin.service.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Tambah Jadwal
            </a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Armada</th>
                    <th>Tanggal Service</th>
                    <th>Jenis</th>
                    <th>Biaya (Rp)</th>
                    <th>Catatan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><strong><?php echo e($service->armada->merk ?? '—'); ?> (<?php echo e($service->armada->nomor_polisi ?? '—'); ?>)</strong></td>
                    <td><?php echo e($service->tanggal_service->format('d F Y')); ?></td>
                    <td><?php echo e($service->jenis_service); ?></td>
                    <td><?php echo e(number_format($service->biaya, 2)); ?></td>
                    <td><?php echo e(Str::limit($service->catatan, 50)); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.service.show', $service)); ?>" class="btn btn-info btn-sm">
                            <i class="fas fa-eye"></i> View
                        </a>
                        <a href="<?php echo e(route('admin.service.edit', $service)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <form action="<?php echo e(route('admin.service.destroy', $service)); ?>" method="POST" style="display:inline;" 
                              onsubmit="return confirm('Yakin ingin menghapus?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">Belum ada jadwal service</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armada-project\resources\views/admin/service/index.blade.php ENDPATH**/ ?>