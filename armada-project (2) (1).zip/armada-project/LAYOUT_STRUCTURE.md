# 🎨 Struktur Layout Header & Footer Website

Penjelasan bagaimana header dan footer bisa sama di semua halaman (DRY - Don't Repeat Yourself).

---

## 📍 Lokasi File Layout

Semua file layout ada di:
```
📁 resources/views/layouts/
├── admin.blade.php          ← Layout untuk Admin Panel
├── public.blade.php         ← Layout untuk Website Public
├── app.blade.php            ← Layout default (jarang dipakai)
├── guest.blade.php          ← Layout untuk auth pages
└── navigation.blade.php     ← Komponen navigasi (jarang dipakai)
```

---

## 🏗️ Konsep: Template Inheritance (Warisan Template)

### Cara Kerjanya:

```
layouts/admin.blade.php (Layout Master)
    ↑
    │ @extends('layouts.admin')
    │
admin/dashboard.blade.php (Child View)
admin/armada/index.blade.php (Child View)
admin/tracking/index.blade.php (Child View)
... dan semua halaman admin lainnya
```

### Bagaimana Bisa Sama di Semua Page?

1. **Layout Master** berisi struktur umum (header, navbar, sidebar, footer)
2. **Child Views** (halaman spesifik) hanya berisi konten UNIK mereka
3. Laravel Blade engine akan **merge** keduanya menjadi halaman final

**Analogi:** 
- Layout Master = Kerangka rumah (dinding, pintu, jendela)
- Child View = Furniture & dekorasi ruangan
- Hasil akhir = Rumah lengkap dengan furniture

---

## 📋 ADMIN LAYOUT STRUCTURE

### File: `resources/views/layouts/admin.blade.php` (357 baris)

```
┌─────────────────────────────────────────────────────┐
│         <!DOCTYPE html> + <head> + CSS Links        │  ← Bagian <head>
├─────────────────────────────────────────────────────┤
│                                                     │
│  ┌───────────────────────────────────────────────┐ │
│  │  NAVBAR (Top Navigation Bar)                  │ │
│  │  - Logo "Fleet Management"                    │ │
│  │  - Menu Dashboard                             │ │
│  │  - Notifikasi (Bell Icon)                     │ │
│  │  - User Account Dropdown (Name + Logout)      │ │
│  └───────────────────────────────────────────────┘ │
│                                                     │
│  ┌────────────┐ ┌─────────────────────────────┐   │
│  │  SIDEBAR   │ │                             │   │
│  │  (Left)    │ │  CONTENT                    │   │
│  │            │ │  @yield('content')          │   │
│  │ - User     │ │                             │   │
│  │   Profile  │ │  ← Child view content       │   │
│  │ - Menu     │ │     diletakkan di sini      │   │
│  │   Armada   │ │                             │   │
│  │   Driver   │ │  @section('title')          │   │
│  │   Rute     │ │  @section('content')        │   │
│  │   Tracking │ │  @yield('css')              │   │
│  │   Gudang   │ │  @yield('js')               │   │
│  │   Tarif    │ │                             │   │
│  │   Logout   │ │                             │   │
│  └────────────┘ └─────────────────────────────┘   │
│                                                     │
├─────────────────────────────────────────────────────┤
│  jQuery + Bootstrap + AdminLTE JS + Custom Scripts │  ← Bagian </body>
└─────────────────────────────────────────────────────┘
```

### Komponen Utama:

#### 1. **HEAD** (Baris 1-17)
```php
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Admin Dashboard') - Fleet Management</title>

    <!-- Google Font -->
    <link rel="stylesheet" href="...fonts.googleapis...">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="...font-awesome...">
    <!-- AdminLTE CSS Framework -->
    <link rel="stylesheet" href="...admin-lte.min.css">
    
    @yield('css')  ← Child view bisa tambah CSS di sini
</head>
```

#### 2. **NAVBAR** (Baris 20-75)
```blade
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left: Menu Toggle & Dashboard Link -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item">
            <a href="{{ route('admin.dashboard') }}" class="nav-link">Dashboard</a>
        </li>
    </ul>

    <!-- Right: Notifikasi & User Account -->
    <ul class="navbar-nav ml-auto">
        <!-- Notifikasi Dropdown -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="far fa-bell"></i>
                @if($count)
                    <span class="badge badge-warning">{{ $count }}</span>
                @endif
            </a>
            <div class="dropdown-menu">
                <!-- Notifikasi daftar -->
            </div>
        </li>

        <!-- User Account -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="far fa-user"></i>
                <span>{{ Auth::user()->name }}</span>
            </a>
            <div class="dropdown-menu">
                <a href="{{ route('logout') }}" class="dropdown-item">Logout</a>
            </div>
        </li>
    </ul>
</nav>
```

#### 3. **SIDEBAR** (Baris 80-170)
```blade
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="{{ route('admin.dashboard') }}" class="brand-link">
        <i class="fas fa-bus brand-image"></i>
        <span class="brand-text">Fleet Management</span>
    </a>

    <!-- Sidebar Menu -->
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar">
                <li class="nav-item">
                    <a href="{{ route('admin.dashboard') }}" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.armada.index') }}" class="nav-link">
                        <i class="fas fa-bus"></i>
                        <p>Armada</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.driver.index') }}" class="nav-link">
                        <i class="fas fa-users"></i>
                        <p>Driver</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.rute.index') }}" class="nav-link">
                        <i class="fas fa-route"></i>
                        <p>Rute</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.tracking.index') }}" class="nav-link">
                        <i class="fas fa-shipping-fast"></i>
                        <p>Tracking</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.gudang.index') }}" class="nav-link">
                        <i class="fas fa-warehouse"></i>
                        <p>Gudang</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('admin.tarif.index') }}" class="nav-link">
                        <i class="fas fa-calculator"></i>
                        <p>Tarif</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
```

#### 4. **CONTENT AREA** (Tempat Child View)
```blade
<!-- Main Content -->
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">@yield('page-title')</h1>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="container-fluid">
            @yield('content')  ← CONTENT dari child view ditampilkan di sini!
        </div>
    </div>
</div>
```

#### 5. **FOOTER + SCRIPTS** (Baris 330-357)
```blade
<!-- Control Sidebar (Optional) -->
<aside class="control-sidebar control-sidebar-dark">
</aside>

<!-- jQuery + Bootstrap + AdminLTE JS -->
<script src="...jquery..."></script>
<script src="...bootstrap..."></script>
<script src="...admin-lte..."></script>

@yield('js')          ← Child view bisa tambah JS di sini
@stack('scripts')     ← Alternative untuk JS

<!-- Logout Modal -->
<div class="modal fade" id="logoutModal">
    <!-- Modal content -->
</div>

<script>
    // Auto logout confirmation
    // Auto hide alerts
    // Etc.
</script>
</body>
</html>
```

---

## 📋 PUBLIC LAYOUT STRUCTURE

### File: `resources/views/layouts/public.blade.php` (352 baris)

```
┌──────────────────────────────────────────────────┐
│  <!DOCTYPE html> + <head> + Bootstrap + CSS     │  ← Bagian <head>
├──────────────────────────────────────────────────┤
│                                                  │
│  ┌──────────────────────────────────────────┐  │
│  │  NAVBAR (Top Navigation - Bootstrap)      │  │
│  │  - Logo "Fleet Management"                │  │
│  │  - Menu Links:                            │  │
│  │    • Armada (Info)                        │  │
│  │    • Layanan (Rute)                       │  │
│  │    • Profil Tim (Driver)                  │  │
│  │    • Pelacakan (Tracking)                 │  │
│  │    • Fasilitas (Gudang + Service)         │  │
│  │    • Tarif (Ongkir)                       │  │
│  │    • Login/User Account                   │  │
│  └──────────────────────────────────────────┘  │
│                                                  │
│  ┌──────────────────────────────────────────┐  │
│  │                                          │  │
│  │         CONTENT AREA                     │  │
│  │         @yield('content')                │  │
│  │                                          │  │
│  │    ← Child view content di sini          │  │
│  │                                          │  │
│  └──────────────────────────────────────────┘  │
│                                                  │
├──────────────────────────────────────────────────┤
│  FOOTER (Gradient Purple)                       │
│  - Company Info                                │
│  - Links (About, Contact, Privacy)             │
│  - Social Media                                │
│  - Copyright © 2025                            │
├──────────────────────────────────────────────────┤
│  Bootstrap JS + jQuery + Custom Scripts        │  ← Bagian </body>
└──────────────────────────────────────────────────┘
```

### Komponen Utama:

#### 1. **HEAD** (Baris 1-43)
```php
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Home') - Fleet Management</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="...bootstrap@5.3.2..." rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="...font-awesome...">
    
    @yield('css')  ← Child view bisa tambah CSS
    
    <style>
        /* Custom Global Styles */
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1;
        }
        footer {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            margin-top: auto;
        }
    </style>
</head>
```

#### 2. **NAVBAR** (Baris 90-240)
```blade
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <!-- Brand Logo -->
        <a class="navbar-brand" href="/">
            <i class="fas fa-bus"></i> Fleet Management
        </a>

        <!-- Toggler (Mobile) -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation Links -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/armada">
                        <i class="fas fa-bus"></i> Info Armada
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="layananDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-map-location-dot"></i> Layanan
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="/cek-area-layanan">
                                <i class="fas fa-route"></i> Cek Area Layanan
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/lokasi-gudang">
                                <i class="fas fa-warehouse"></i> Lokasi Gudang
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/profil-tim">
                        <i class="fas fa-users"></i> Profil Tim
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="pelacakanDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-box"></i> Pelacakan & Tarif
                    </a>
                    <ul class="dropdown-menu">
                        <li>
                            <a class="dropdown-item" href="/cek-resi">
                                <i class="fas fa-search-location"></i> Cek Resi
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="/cek-ongkir">
                                <i class="fas fa-calculator"></i> Cek Ongkir
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/info-perawatan">
                        <i class="fas fa-tools"></i> Info Perawatan
                    </a>
                </li>
                
                @auth
                    <li class="nav-item">
                        <a class="nav-link" href="/admin/dashboard">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> {{ Auth::user()->name }}
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="{{ route('logout') }}">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </li>
                @else
                    <li class="nav-item">
                        <a class="nav-link" href="/login">
                            <i class="fas fa-sign-in-alt"></i> Login
                        </a>
                    </li>
                @endauth
            </ul>
        </div>
    </div>
</nav>
```

#### 3. **MAIN CONTENT** (Tempat Child View)
```blade
<main>
    <div class="container-fluid">
        @yield('content')  ← CONTENT dari child view ditampilkan di sini!
    </div>
</main>
```

#### 4. **FOOTER** (Baris 245-352)
```blade
<footer class="text-white mt-5">
    <div class="container-fluid py-5">
        <div class="row">
            <div class="col-md-3 mb-4">
                <h5>About Us</h5>
                <p>Fleet Management adalah solusi transportasi terpercaya...</p>
            </div>
            <div class="col-md-3 mb-4">
                <h5>Quick Links</h5>
                <ul>
                    <li><a href="/armada">Info Armada</a></li>
                    <li><a href="/cek-resi">Cek Resi</a></li>
                    <li><a href="/cek-ongkir">Cek Ongkir</a></li>
                </ul>
            </div>
            <div class="col-md-3 mb-4">
                <h5>Contact</h5>
                <p>Email: info@armada.local</p>
                <p>Phone: +62 123 456 789</p>
            </div>
            <div class="col-md-3 mb-4">
                <h5>Follow Us</h5>
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; 2025 Fleet Management. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="...bootstrap@5.3.2..."></script>
@yield('js')
</body>
</html>
```

---

## 🔗 Cara Child View Menggunakan Layout

### Contoh: Dashboard Admin (`admin/dashboard.blade.php`)

```blade
@extends('layouts.admin')                    ← Gunakan layout admin.blade.php

@section('title', 'Dashboard')              ← Set title
@section('page-title', 'Dashboard')         ← Set page title

@section('css')
<style>
    /* CSS khusus untuk halaman ini */
</style>
@endsection

@section('content')
    <!-- Konten dashboard -->
    <div class="row">
        <!-- Semua konten dashboard di sini -->
    </div>
@endsection

@section('js')
<script>
    // JS khusus untuk halaman ini
</script>
@endsection
```

**Yang akan terjadi:**
1. Laravel membaca `layouts/admin.blade.php` sebagai template master
2. `@section('title', 'Dashboard')` akan mengganti `@yield('title', 'Admin Dashboard')`
3. `@section('content')` akan mengganti `@yield('content')`
4. `@section('css')` akan mengganti `@yield('css')`
5. Result = Halaman lengkap dengan navbar + sidebar + content + footer

### Contoh: Public Page (`public/armada/index.blade.php`)

```blade
@extends('layouts.public')              ← Gunakan layout public.blade.php

@section('title', 'Info Armada')       ← Set title (untuk <title> tag)

@section('content')
    <!-- Hero Section -->
    <div class="hero-section">
        ...
    </div>

    <!-- Armada Grid -->
    <div class="container">
        ...
    </div>
@endsection

@section('css')
<style>
    .armada-card { ... }
</style>
@endsection
```

---

## 🎯 Alur Loading Page

Ketika user membuka `/admin/dashboard`:

```
1. Laravel Router menerima request /admin/dashboard
2. Route di-route ke AdminDashboardController::show()
3. Controller menjalankan: return view('admin.dashboard')
4. Laravel mencari file: resources/views/admin/dashboard.blade.php
5. Blade engine melihat: @extends('layouts.admin')
6. Blade engine membaca: resources/views/layouts/admin.blade.php
7. Blade engine merge:
   - Layout master = navbar + sidebar + footer
   - Child content = @section('content') dari dashboard.blade.php
8. Hasil final = HTML lengkap
9. Browser render halaman dengan navbar + sidebar + dashboard content + footer
```

---

## ✨ Keuntungan Sistem Layout

### 1. **DRY (Don't Repeat Yourself)**
- ✅ Tidak perlu copy-paste navbar di setiap halaman
- ✅ 1 tempat perubahan → semua halaman berubah

### 2. **Consistent Design**
- ✅ Semua halaman admin punya layout sama
- ✅ Semua halaman public punya layout sama
- ✅ Brand consistency terjaga

### 3. **Easy Maintenance**
- ✅ Ganti navbar? Edit hanya 1 file
- ✅ Tambah menu? Edit sidebar di layout
- ✅ Update footer? Edit footer di layout

### 4. **Scalability**
- ✅ Bisa buat layout berbeda untuk berbagai tipe halaman
- ✅ Contoh: public layout, admin layout, guest layout, etc.

### 5. **Flexible Content**
- ✅ Setiap halaman bisa punya CSS/JS unik sendiri
- ✅ Tidak semua CSS di-load untuk semua halaman
- ✅ Optimisasi loading performance

---

## 🎨 Kustomisasi Layout

### Jika Ingin Menambah Menu di Navbar Admin:

**File:** `resources/views/layouts/admin.blade.php` (cari bagian navbar)

```blade
<li class="nav-item">
    <a href="{{ route('admin.newpage.index') }}" class="nav-link">
        <i class="fas fa-icon-name"></i>
        <p>New Page</p>
    </a>
</li>
```

### Jika Ingin Ubah Warna Footer Public:

**File:** `resources/views/layouts/public.blade.php` (cari bagian footer style)

```blade
footer {
    background: linear-gradient(135deg, #NEW_COLOR_1 0%, #NEW_COLOR_2 100%);
    color: white;
}
```

### Jika Ingin Tambah CSS Global:

**File:** `resources/views/layouts/admin.blade.php` (di dalam `<head>`)

```blade
<style>
    /* Tambah CSS di sini */
    .custom-class {
        color: red;
    }
</style>
```

---

## 📊 Perbandingan Struktur

| Aspek | Admin Layout | Public Layout |
|-------|-------------|---------------|
| Framework | AdminLTE 3.2 | Bootstrap 5.3 |
| Navbar | Fixed top | Fixed top |
| Sidebar | Ya (Left) | Tidak |
| Footer | Implicit | Explicit |
| Design | Professional/Corporate | Modern/Trendy |
| Responsive | Ya | Ya |
| Mobile Menu | Sidebar toggle | Hamburger |
| File | 357 baris | 352 baris |
| Routes | Admin only | Public + Auth |

---

**Kesimpulan:** Layout inheritance di Laravel Blade adalah cara yang sangat efisien untuk menciptakan website yang konsisten, mudah dirawat, dan scalable! 🚀
